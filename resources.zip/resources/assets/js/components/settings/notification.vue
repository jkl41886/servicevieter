<template>
    <div class="tab-pane active" id="compsaswda" role="tabpanel">
        <div class="col-lg-125">
            <div class="col-lg-12">
                <div class="tabcontent" id="Information" style="display: block;">
                    <div class="row">
                        <div class="notif">
                            <div style="height: 100%" class="col-lg-12 col-md-12 col-sm-12">
                                <div class="panel panel-default">
                                    <div style="text-align: center" class="panel-heading">
                                        Notification Settings
                                    </div>
                                    <ul class="list-group" style=" flex-direction: column;">
                                        <li class="list-group-item">
                                            Bootstrap Switch Default
                                            <div style=" margin: 0px 0;width: 300px;" class="material-switch pull-right">
                                                <div class="switch-container">
                                                <div class="switch switch-yellow">
                                                    <input class="switch-input" name="view1" value="week1" id="week1" checked="" type="radio">
                                                    <label for="week1" class="switch-label switch-label-off">YES</label>
                                                    <input class="switch-input" name="view1" value="month3" id="month1" type="radio">
                                                    <label for="month1" class="switch-label switch-label-on">NO</label>
                                                    <span class="switch-selection"></span>
                                                </div>
                                                </div>
                                            </div>
                                        </li>
                                        <li class="list-group-item">
                                            Bootstrap Switch Primary
                                            <div style=" margin: 0px 0;width: 300px;" class="material-switch pull-right">
                                                <div class="switch-container">
                                                    <div class="switch switch-yellow">
                                                        <input class="switch-input" name="view2" value="week2" id="week2" checked="" type="radio">
                                                        <label for="week2" class="switch-label switch-label-off">YES</label>
                                                        <input class="switch-input" name="view2" value="month2" id="month2" type="radio">
                                                        <label for="month2" class="switch-label switch-label-on">NO</label>
                                                        <span class="switch-selection"></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                        <li class="list-group-item">
                                            Bootstrap Switch Success
                                            <div style=" margin: 0px 0;width: 300px;" class="material-switch pull-right">
                                                <div class="switch-container">
                                                    <div class="switch switch-yellow">
                                                        <input class="switch-input" name="view3" value="week3" id="week3" checked="" type="radio">
                                                        <label for="week3" class="switch-label switch-label-off">YES</label>
                                                        <input class="switch-input" name="view3" value="month3" id="month3" type="radio">
                                                        <label for="month3" class="switch-label switch-label-on">NO</label>
                                                        <span class="switch-selection"></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                        <li class="list-group-item">
                                            Bootstrap Switch Info
                                            <div style=" margin: 0px 0;width:300px;" class="material-switch pull-right">
                                                <div class="switch-container">
                                                    <div class="switch switch-yellow">
                                                        <input class="switch-input" name="view4" value="week4" id="week4" checked="" type="radio">
                                                        <label for="week4" class="switch-label switch-label-off">YES</label>
                                                        <input class="switch-input" name="view4" value="month4" id="month4" type="radio">
                                                        <label for="month4" class="switch-label switch-label-on">NO</label>
                                                        <span class="switch-selection"></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                        <li class="list-group-item">
                                            Bootstrap Switch Warning
                                            <div style=" margin: 0px 0;width:300px;" class="material-switch pull-right">
                                                <div class="switch-container">
                                                    <div class="switch switch-yellow">
                                                        <input class="switch-input" name="view5" value="week5" id="week5" checked="" type="radio">
                                                        <label for="week5" class="switch-label switch-label-off">YES</label>
                                                        <input class="switch-input" name="view5" value="month5" id="month5" type="radio">
                                                        <label for="month5" class="switch-label switch-label-on">NO</label>
                                                        <span class="switch-selection"></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                        <li class="list-group-item">
                                            Bootstrap Switch Danger
                                            <div style=" margin: 0px 0;width: 300px;" class="material-switch pull-right">
                                                <div class="switch-container">
                                                    <div class="switch switch-yellow">
                                                        <input class="switch-input" name="view6" value="week6" id="week6" checked="" type="radio">
                                                        <label for="week6" class="switch-label switch-label-off">YES</label>
                                                        <input class="switch-input" name="view6" value="month6" id="month6" type="radio">
                                                        <label for="month6" class="switch-label switch-label-on">NO</label>
                                                        <span class="switch-selection"></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
                                                                
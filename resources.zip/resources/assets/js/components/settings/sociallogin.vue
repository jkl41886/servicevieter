<template>
    <div class="tab-pane active" id="ownerinfo" role="tabpanel">
        <div style="background: #f3f3f3f3;" class="col-lg-12">
            <div class="col-lg-1">
            </div>
            <div style="background: white;" class="col-lg-10">
                <div class="socail-icns">
                    <h2>
                        Facebook Account
                    </h2>
                    <p>
                        You Guru account is linked with your Facebook account Rohan Sulaiman. This means you can log in with Facebook.
                    </p>
                    <p>
                        <a href="#">
                        <img src="img/1.png">
                        </a>
                    </p>
                    <p>
                    </p>
                        <hr>
                        <h2>
                            Facebook Account
                        </h2>
                    <p>
                        You Guru account is linked with your Facebook account Rohan Sulaiman. This means you can log in with Facebook.
                    </p>
                    <p>
                        <a href="#">
                            <img src="img/3.png">
                        </a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</template>
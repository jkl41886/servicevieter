@php
$title = "UserSection";
@endphp

@extends('layouts.master')

@section('content')

@endsection